package com.example.billingYsfi.exeption;

public class ProductItemNotFoundException extends Throwable {
    public ProductItemNotFoundException(String s) {
    }

}
